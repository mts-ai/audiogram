import functools
import time
import wave
from collections.abc import Iterable
from typing import Callable, ParamSpec, TypeVar

import botocore.exceptions
import click
import grpc
import keycloak
from dynaconf import ValidationError

T = TypeVar("T")

P = ParamSpec("P")


def errors_handler(func: Callable[P, int | None]) -> Callable[P, int | None]:
    @functools.wraps(func)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> int | None:
        context = click.get_current_context()

        try:
            return func(*args, **kwargs)

        except ValidationError as err:
            context.fail(err.message)  # This will hint user to use --help

        except KeyboardInterrupt:
            click.echo("Interrupted!")
            context.exit(1)

        except FileNotFoundError as err:
            click.echo(err.strerror)
            context.exit(err.errno or 1)

        except keycloak.KeycloakError as err:
            click.echo(f"Keycloak auth error: {err.error_message}")
            context.exit(1)

        except grpc.RpcError as err:
            err_code = err.code()
            err_details = err.details()

            if err_code == grpc.StatusCode.RESOURCE_EXHAUSTED:
                click.echo(
                    "Request got rate-limited (gRPC error RESOURCE_EXHAUSTED), "
                    "try again later.\n"
                    f"Details: {err_details}"
                )
                context.exit(1)

            click.echo("gRPC call failed!")
            click.echo(f"code: {err_code}")
            click.echo(f"details: {err_details}")
            context.exit(1)

        except wave.Error as err:
            click.echo(f"Error while trying to open audio file: {err}")
            click.echo("This client only supports WAV files in PCM (int16le) format.")
            context.exit(1)

        except botocore.exceptions.ClientError as err:
            click.echo(f"S3 request error: {err}")
            context.exit(1)

    return wrapper


def respect_rate_limit(iterator: Iterable[T]) -> Iterable[T]:
    while True:
        try:
            yield from iterator
            break
        except grpc.RpcError as err:
            if err.code() != grpc.StatusCode.RESOURCE_EXHAUSTED:
                raise

            click.echo("\n=== Got RESOURCE_EXHAUSTED (hit rate limit), waiting 1 second ===")
            time.sleep(1.0)
