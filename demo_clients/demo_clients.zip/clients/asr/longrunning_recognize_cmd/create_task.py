from pathlib import Path

import click
import grpc

from clients.asr.utils.arguments import common_asr_options
from clients.asr.utils.definitions import (
    DEFAULT_VAD_F_MIN_SILENCE_MS,
    DEFAULT_VAD_F_MIN_SPEECH_MS,
    DEFAULT_VAD_F_SPEECH_PAD_MS,
    DEFAULT_VAD_F_THRESHOLD,
)
from clients.asr.utils.option_types import VADAlgo, VADMode, VAResponseMode
from clients.asr.utils.request import (
    make_antispoofing_config,
    make_context_dictionary_config,
    make_recognition_config,
    make_speaker_labeling_config,
    make_substitution_dictionary_config,
    make_va_config,
)
from clients.common_utils.arguments import common_options_in_settings
from clients.common_utils.audio import AudioFile
from clients.common_utils.auth import get_auth_metadata
from clients.common_utils.config import SettingsProtocol
from clients.common_utils.errors import errors_handler
from clients.common_utils.grpc import (
    get_extra_metadata,
    open_grpc_channel,
    print_metadata,
    ssl_creds_from_settings,
)
from clients.genproto import (
    longrunning_stt_pb2 as lr_stt_pb2,
    longrunning_stt_pb2_grpc as lr_stt_pb2_grpc,
    longrunning_task_pb2 as lr_task_pb2,
)

from .common_parts import s3_upload_audio

AudioPath = lr_stt_pb2.LongRunningRecognizeRequest.AudioPath
TaskStatus = lr_task_pb2.Task.Status


@click.command(
    help="Create long-running recognition task",
)
@errors_handler
@common_options_in_settings
@common_asr_options(
    DEFAULT_VAD_F_THRESHOLD,
    DEFAULT_VAD_F_MIN_SILENCE_MS,
    DEFAULT_VAD_F_SPEECH_PAD_MS,
    DEFAULT_VAD_F_MIN_SPEECH_MS,
)
@click.option(
    "--s3-address",
    required=True,
    help="S3 storage address where to load audio for recognition",
)
@click.option(
    "--s3-access-key",
    required=True,
    help="Access key for S3",
)
@click.option(
    "--s3-secret-key",
    required=True,
    help="Secret key for S3",
)
@click.option(
    "--s3-bucket",
    default="longrunningaudiofiles",
    help="Set custom S3 bucket to load audio",
)
@click.option(
    "--s3-verify/--no-s3-verify",
    default=True,
    help="Enable/disable SSL certificate validation",
)
@click.option(
    "--s3-ca-cert-bundle",
    type=click.Path(file_okay=True, dir_okay=False, path_type=Path),
    default=None,
    help=(
        "Path to the CA certificate bundle file (PEM-encoded). "
        "If specified, they will be used to verify SSL certificates."
    ),
    metavar="<path>",
)
def longrunning_create_task(
    settings: SettingsProtocol,
    audio_file: str,
    model: str,
    enable_word_time_offsets: bool,
    enable_punctuator: bool,
    enable_denormalization: bool,
    enable_speaker_labeling: bool,
    enable_genderage: bool,
    enable_antispoofing: bool,
    va_response_mode: VAResponseMode,
    vad_algo: VADAlgo,
    vad_mode: VADMode,
    vad_threshold: float,
    vad_speech_pad_ms: int,
    vad_min_silence_ms: int,
    vad_min_speech_ms: int,
    dep_smoothed_window_threshold: float,
    dep_smoothed_window_ms: int,
    enhanced_beginning_window_ms: int,
    enhanced_beginning_threshold: float,
    enhanced_ending_window_ms: int,
    enhanced_ending_threshold: float,
    target_speech_beginning_window_ms: int,
    target_speech_beginning_threshold: float,
    target_speech_ending_window_ms: int,
    target_speech_ending_threshold: float,
    antispoofing_far: int | None,
    antispoofing_frr: int | None,
    antispoofing_max_duration_for_analysis: int | None,
    speakers_max: int | None,
    speakers_num: int | None,
    wfst_dictionary_name: str,
    wfst_dictionary_weight: float,
    subst_dictionary_name: str | None,
    subst_dictionary_data: str | None,
    s3_address: str,
    s3_access_key: str,
    s3_secret_key: str,
    s3_bucket: str,
    s3_verify: bool,
    s3_ca_cert_bundle: Path | None,
) -> None:
    auth_metadata = get_auth_metadata(
        settings.sso_url,
        settings.realm,
        settings.client_id,
        settings.client_secret,
        settings.iam_account,
        settings.iam_workspace,
        settings.verify_sso,
    )
    metadata = (*auth_metadata, *get_extra_metadata(settings))

    audio = AudioFile(audio_file)

    click.echo(
        f"Request parameters:\n"
        f"Audio sample rate: {audio.sample_rate}\n"
        f"Audio channels: {audio.channel_count}\n"
        f"VAD algorithm: {vad_algo.name.upper()}\n"
        f"Genderage enabled: {enable_genderage}\n"
        f"Punctuator enabled: {enable_punctuator}\n"
        f"Denormalization enabled: {enable_denormalization}\n"
        f"Speaker labeling enabled: {enable_speaker_labeling}\n"
        f"Word time offsets enabled: {enable_word_time_offsets}\n"
        f"Antispoofing enabled: {enable_antispoofing}\n"
    )

    file_key = s3_upload_audio(
        audio_file,
        s3_address,
        s3_access_key,
        s3_secret_key,
        s3_bucket,
        s3_verify,
        s3_ca_cert_bundle,
    )

    # Make request to the API

    va_config = make_va_config(
        vad_algo,
        vad_mode,
        vad_threshold,
        vad_min_silence_ms,
        vad_speech_pad_ms,
        vad_min_speech_ms,
        dep_smoothed_window_threshold,
        dep_smoothed_window_ms,
        enhanced_beginning_window_ms,
        enhanced_beginning_threshold,
        enhanced_ending_window_ms,
        enhanced_ending_threshold,
        target_speech_beginning_window_ms,
        target_speech_beginning_threshold,
        target_speech_ending_window_ms,
        target_speech_ending_threshold,
    )
    as_config = make_antispoofing_config(
        enable_antispoofing,
        antispoofing_far,
        antispoofing_frr,
        antispoofing_max_duration_for_analysis,
    )
    sl_config = make_speaker_labeling_config(
        enable_speaker_labeling,
        speakers_max,
        speakers_num,
    )
    wfst_config = make_context_dictionary_config(
        wfst_dictionary_name,
        wfst_dictionary_weight,
    )
    subst_dict_config = make_substitution_dictionary_config(
        subst_dictionary_name,
        subst_dictionary_data,
    )
    recognition_config = make_recognition_config(
        model,
        va_config,
        va_response_mode,
        audio.sample_rate,
        audio.channel_count,
        enable_genderage,
        enable_word_time_offsets,
        enable_punctuator,
        enable_denormalization,
        as_config,
        sl_config,
        wfst_config,
        subst_dict_config,
    )
    request = lr_stt_pb2.LongRunningRecognizeRequest(
        config=recognition_config,
        s3_audio_path=[
            AudioPath(
                bucket_name=s3_bucket,
                object_name=file_key,
            ),
        ],
    )

    click.echo(f"Connecting to gRPC server - {settings.api_address}\n")

    with open_grpc_channel(
        settings.api_address,
        ssl_creds_from_settings(settings),
    ) as channel:
        stub = lr_stt_pb2_grpc.LongRunningStub(channel)

        response: lr_task_pb2.Task
        call: grpc.Call
        response, call = stub.LongRunningRecognize.with_call(
            request,
            metadata=metadata,
            timeout=settings.timeout,
        )

        click.echo("Response metadata:")
        print_metadata(call.initial_metadata())

        task_id = response.id

        click.echo(f"\nTask ID: {task_id} | Status: {TaskStatus.Name(response.status)}")
