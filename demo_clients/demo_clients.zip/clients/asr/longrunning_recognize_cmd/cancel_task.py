import click
import grpc

from clients.common_utils.arguments import common_options_in_settings
from clients.common_utils.auth import get_auth_metadata
from clients.common_utils.config import SettingsProtocol
from clients.common_utils.errors import errors_handler
from clients.common_utils.grpc import (
    get_extra_metadata,
    open_grpc_channel,
    print_metadata,
    ssl_creds_from_settings,
)
from clients.genproto import (
    longrunning_stt_pb2_grpc as lr_stt_pb2_grpc,
    longrunning_task_pb2 as lr_task_pb2,
)

TaskStatus = lr_task_pb2.Task.Status


@click.command(
    help="Cancel long-running recognition request task",
)
@errors_handler
@common_options_in_settings
@click.option(
    "--task-id",
    required=True,
    help="Task ID to get info",
)
def longrunning_cancel_task(
    settings: SettingsProtocol,
    task_id: str,
) -> None:
    auth_metadata = get_auth_metadata(
        settings.sso_url,
        settings.realm,
        settings.client_id,
        settings.client_secret,
        settings.iam_account,
        settings.iam_workspace,
        settings.verify_sso,
    )
    metadata = (*auth_metadata, *get_extra_metadata(settings))

    click.echo(f"Task ID: {task_id}")

    click.echo(f"Connecting to gRPC server - {settings.api_address}\n")

    with open_grpc_channel(
        settings.api_address,
        ssl_creds_from_settings(settings),
    ) as channel:
        stub = lr_stt_pb2_grpc.LongRunningStub(channel)

        request = lr_task_pb2.TaskRequest(task_id=task_id)

        response: lr_task_pb2.Task
        call: grpc.Call
        response, call = stub.CancelTask.with_call(
            request,
            metadata=metadata,
            timeout=settings.timeout,
        )

        click.echo("Initial response metadata:")
        print_metadata(call.initial_metadata())

        click.echo(f"\nTask status: {TaskStatus.Name(response.status)}")
