import uuid
from pathlib import Path

import boto3
import click
import urllib3
from botocore.exceptions import ClientError


def s3_upload_audio(
    audio_file: str,
    s3_address: str,
    s3_access_key: str,
    s3_secret_key: str,
    s3_bucket: str,
    s3_verify: bool = True,
    s3_ca_certificate_bundle_path: Path | None = None,
) -> str:
    """Upload audio to S3 storage."""
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    verify_arg: str | bool = False

    if s3_verify and s3_ca_certificate_bundle_path is not None:
        verify_arg = str(s3_ca_certificate_bundle_path)

    s3_client = boto3.client(
        "s3",
        endpoint_url=s3_address,
        aws_access_key_id=s3_access_key,
        aws_secret_access_key=s3_secret_key,
        # verify=False disables SSL certificate verification completely
        # verify='path/to/ca_cert_bundle.pem' sets CA certificate bundle to use for verification
        verify=verify_arg,
    )

    try:
        s3_client.head_bucket(Bucket=s3_bucket)
    except ClientError as err:
        error_code = err.response.get("Error", {}).get("Code")
        if error_code != "404":
            raise

        click.echo(f"Bucket {s3_bucket} was not found")
        s3_client.create_bucket(Bucket=s3_bucket)
        click.echo(f"Created bucket {s3_bucket}")

    file_key = str(uuid.uuid4())

    s3_client.upload_file(
        audio_file,
        s3_bucket,
        file_key,
    )

    click.echo(f"Uploaded file to S3. Bucket: {s3_bucket} Key: {file_key}")
    return file_key
