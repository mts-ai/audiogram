import click

from .preset_recognize_cmd import preset_file_recognize, preset_recognize


@click.group(help="Speech recognition clients that use presets")
def preset_recognize_group() -> None:
    pass


preset_recognize_group.add_command(preset_file_recognize, "file")
preset_recognize_group.add_command(preset_recognize, "stream")
