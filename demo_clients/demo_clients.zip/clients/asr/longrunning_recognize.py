import click

from .longrunning_recognize_cmd import (
    longrunning_cancel_task,
    longrunning_create_task,
    longrunning_full,
    longrunning_get_task_info,
)


@click.group(help="Long-running speech recognition clients for big audio files")
def longrunning_recognize() -> None:
    pass


longrunning_recognize.add_command(longrunning_full, "full")
longrunning_recognize.add_command(longrunning_create_task, "create")
longrunning_recognize.add_command(longrunning_get_task_info, "info")
longrunning_recognize.add_command(longrunning_cancel_task, "cancel")
