import time
from collections.abc import Iterator
from itertools import islice

import click
import grpc

from clients.asr.utils.definitions import CHUNK_LEN_MS
from clients.asr.utils.response import (
    print_recognize_response,
    print_recognize_response_dialogue_format,
)
from clients.common_utils.arguments import common_options_in_settings
from clients.common_utils.audio import AudioFile
from clients.common_utils.auth import get_auth_metadata
from clients.common_utils.config import SettingsProtocol
from clients.common_utils.errors import errors_handler, respect_rate_limit
from clients.common_utils.grpc import (
    get_extra_metadata,
    open_grpc_channel,
    print_metadata,
    ssl_creds_from_settings,
)
from clients.genproto import stt_presets_pb2, stt_presets_pb2_grpc, stt_response_pb2


def preset_stream_request_iterator(
    preset_config: stt_presets_pb2.Preset,
    audio_chunks: Iterator[bytes],
    wait_ms: int,
) -> Iterator[stt_presets_pb2.RecognizeRequest]:
    yield stt_presets_pb2.RecognizeRequest(preset=preset_config)

    for chunk in islice(audio_chunks, 1):
        yield stt_presets_pb2.RecognizeRequest(audio=chunk)

    for chunk in audio_chunks:
        time.sleep(wait_ms / 1000)
        yield stt_presets_pb2.RecognizeRequest(audio=chunk)


@click.command(
    help="Online (stream) speech recognition using preset configuration",
)
@errors_handler
@common_options_in_settings
@click.option(
    "--audio-file",
    required=True,
    type=click.Path(exists=True, dir_okay=False),
    help="path for audio file with recorded voice (required)",
    metavar="<.wav path>",
)
@click.option(
    "--preset-name",
    required=True,
    help="name of the preset to use",
)
@click.option(
    "--preset-version",
    type=int,
    required=True,
    help="version of the preset to use",
)
@click.option(
    "--rt",
    "realtime",
    is_flag=True,
    default=False,
    help="enable emulation of real-time audio streaming",
)
@click.option(
    "--chunk-len",
    "chunk_len_ms",
    type=click.IntRange(500, 2000),
    default=CHUNK_LEN_MS,
    help="set audio chunk length in milliseconds (from 500 to 2000)",
)
@click.option(
    "--dialogue-output",
    "enable_dialogue_output",
    is_flag=True,
    default=False,
    help="switch output to a more compact format using only hypothesis and speaker_id",
)
def preset_recognize(
    settings: SettingsProtocol,
    audio_file: str,
    preset_name: str,
    preset_version: int,
    realtime: bool,
    chunk_len_ms: int,
    enable_dialogue_output: bool,
) -> None:
    auth_metadata = get_auth_metadata(
        settings.sso_url,
        settings.realm,
        settings.client_id,
        settings.client_secret,
        settings.iam_account,
        settings.iam_workspace,
        settings.verify_sso,
    )
    metadata = (*auth_metadata, *get_extra_metadata(settings))

    audio = AudioFile(audio_file)

    click.echo(
        f"Request parameters:\n"
        f"Audio sample rate: {audio.sample_rate}\n"
        f"Audio channels: {audio.channel_count}\n"
        f"Preset name: {preset_name}\n"
        f"Preset version: {preset_version}\n"
    )

    preset_config = stt_presets_pb2.Preset(
        preset_name=preset_name,
        preset_version=preset_version,
    )
    request_iterator = preset_stream_request_iterator(
        preset_config,
        audio.chunks(chunk_len_ms),
        chunk_len_ms if realtime else 0,
    )

    click.echo(f"Connecting to gRPC server - {settings.api_address}\n")

    with open_grpc_channel(
        settings.api_address,
        ssl_creds_from_settings(settings),
    ) as channel:
        stub = stt_presets_pb2_grpc.STTStub(channel)

        response_iterator: Iterator[stt_response_pb2.RecognizeResponse] | grpc.Call
        response_iterator = stub.Recognize(
            request_iterator,
            metadata=metadata,
            timeout=settings.timeout,
        )

        click.echo("Response metadata:")
        print_metadata(response_iterator.initial_metadata())

        if enable_dialogue_output:
            click.echo("\nResponses:")

        for response_idx, response in enumerate(respect_rate_limit(response_iterator), 1):
            if enable_dialogue_output:
                print_recognize_response_dialogue_format(response, response_idx)
            else:
                click.echo(f"\nResponse #{response_idx}:")
                print_recognize_response(response)
