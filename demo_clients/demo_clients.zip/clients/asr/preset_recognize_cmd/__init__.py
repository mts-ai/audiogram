from .file_recognize import preset_file_recognize
from .recognize import preset_recognize

__all__ = [
    "preset_file_recognize",
    "preset_recognize",
]
