import click
import grpc

from clients.asr.utils.response import (
    print_recognize_response,
    print_recognize_response_dialogue_format,
)
from clients.common_utils.arguments import common_options_in_settings
from clients.common_utils.audio import AudioFile
from clients.common_utils.auth import get_auth_metadata
from clients.common_utils.config import SettingsProtocol
from clients.common_utils.errors import errors_handler
from clients.common_utils.grpc import (
    get_extra_metadata,
    open_grpc_channel,
    print_metadata,
    ssl_creds_from_settings,
)
from clients.genproto import stt_presets_pb2, stt_presets_pb2_grpc, stt_response_pb2


@click.command(
    help="Offline (file) speech recognition using preset configuration",
)
@errors_handler
@common_options_in_settings
@click.option(
    "--audio-file",
    required=True,
    type=click.Path(exists=True, dir_okay=False),
    help="path for audio file with recorded voice (required)",
    metavar="<.wav path>",
)
@click.option(
    "--preset-name",
    required=True,
    help="name of the preset to use",
)
@click.option(
    "--preset-version",
    type=int,
    required=True,
    help="version of the preset to use",
)
@click.option(
    "--dialogue-output",
    "enable_dialogue_output",
    is_flag=True,
    default=False,
    help="switch output to a more compact format using only hypothesis and speaker_id",
)
def preset_file_recognize(
    settings: SettingsProtocol,
    audio_file: str,
    preset_name: str,
    preset_version: int,
    enable_dialogue_output: bool,
) -> None:
    auth_metadata = get_auth_metadata(
        settings.sso_url,
        settings.realm,
        settings.client_id,
        settings.client_secret,
        settings.iam_account,
        settings.iam_workspace,
        settings.verify_sso,
    )
    metadata = (*auth_metadata, *get_extra_metadata(settings))

    audio = AudioFile(audio_file)

    click.echo(
        f"Request parameters:\n"
        f"Audio sample rate: {audio.sample_rate}\n"
        f"Audio channels: {audio.channel_count}\n"
        f"Preset name: {preset_name}\n"
        f"Preset version: {preset_version}\n"
    )

    preset_config = stt_presets_pb2.Preset(
        preset_name=preset_name,
        preset_version=preset_version,
    )
    request = stt_presets_pb2.FileRecognizeRequest(
        preset=preset_config,
        audio=audio.blob,
    )

    click.echo(f"Connecting to gRPC server - {settings.api_address}\n")

    with open_grpc_channel(
        settings.api_address,
        ssl_creds_from_settings(settings),
    ) as channel:
        stub = stt_presets_pb2_grpc.STTStub(channel)

        response: stt_response_pb2.FileRecognizeResponse
        call: grpc.Call
        response, call = stub.FileRecognize.with_call(
            request,
            metadata=metadata,
            timeout=settings.timeout,
        )

        click.echo("Response metadata:")
        print_metadata(call.initial_metadata())

        if enable_dialogue_output:
            click.echo("\nResults:")

        for idx, result in enumerate(response.response, 1):
            if enable_dialogue_output:
                print_recognize_response_dialogue_format(result, idx, True)
            else:
                click.echo(f"\nResult {idx}:")
                print_recognize_response(result, True)
