"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_sym_db = _symbol_database.Default()
from . import response_header_pb2 as response__header__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x12stt_response.proto\x12 mts.ai.audiogram.stt_response.v1\x1a\x15response_header.proto"\xa3\x01\n\x15FileRecognizeResponse\x12E\n\x08response\x18\x01 \x03(\x0b23.mts.ai.audiogram.stt_response.v1.RecognizeResponse\x12C\n\x06header\x18\x02 \x01(\x0b23.mts.ai.audiogram.response_header.v1.ResponseHeader"\xf6\x03\n\x11RecognizeResponse\x12Q\n\nhypothesis\x18\x01 \x01(\x0b2=.mts.ai.audiogram.stt_response.v1.SpeechRecognitionHypothesis\x12\x10\n\x08is_final\x18\x02 \x01(\x08\x12\x0f\n\x07channel\x18\x03 \x01(\x05\x12E\n\x08va_marks\x18\x04 \x03(\x0b23.mts.ai.audiogram.stt_response.v1.VoiceActivityMark\x12O\n\tgenderage\x18\x05 \x01(\x0b2<.mts.ai.audiogram.stt_response.v1.SpeakerGenderAgePrediction\x12I\n\x0fspoofing_result\x18\x06 \x03(\x0b20.mts.ai.audiogram.stt_response.v1.SpoofingResult\x12C\n\x0cspeaker_info\x18\x07 \x01(\x0b2-.mts.ai.audiogram.stt_response.v1.SpeakerInfo\x12C\n\x06header\x18\x08 \x01(\x0b23.mts.ai.audiogram.response_header.v1.ResponseHeader"\xa3\x03\n\x1bSpeechRecognitionHypothesis\x12\x12\n\ntranscript\x18\x01 \x01(\t\x12\x1d\n\x15normalized_transcript\x18\x02 \x01(\t\x12\x12\n\nconfidence\x18\x03 \x01(\x02\x12\x15\n\rstart_time_ms\x18\x04 \x01(\r\x12\x13\n\x0bend_time_ms\x18\x05 \x01(\r\x12U\n\x05words\x18\x06 \x03(\x0b2F.mts.ai.audiogram.stt_response.v1.SpeechRecognitionHypothesis.WordInfo\x12`\n\x10normalized_words\x18\x07 \x03(\x0b2F.mts.ai.audiogram.stt_response.v1.SpeechRecognitionHypothesis.WordInfo\x1aX\n\x08WordInfo\x12\x15\n\rstart_time_ms\x18\x01 \x01(\r\x12\x13\n\x0bend_time_ms\x18\x02 \x01(\r\x12\x0c\n\x04word\x18\x03 \x01(\t\x12\x12\n\nconfidence\x18\x04 \x01(\x02"\xd3\x01\n\x11VoiceActivityMark\x12\\\n\tmark_type\x18\x01 \x01(\x0e2I.mts.ai.audiogram.stt_response.v1.VoiceActivityMark.VoiceActivityMarkType\x12\x11\n\toffset_ms\x18\x02 \x01(\r"M\n\x15VoiceActivityMarkType\x12\x10\n\x0cVA_MARK_NONE\x10\x00\x12\x11\n\rVA_MARK_BEGIN\x10\x01\x12\x0f\n\x0bVA_MARK_END\x10\x02"\x93\x04\n\x1aSpeakerGenderAgePrediction\x12X\n\x06gender\x18\x01 \x01(\x0e2H.mts.ai.audiogram.stt_response.v1.SpeakerGenderAgePrediction.GenderClass\x12R\n\x03age\x18\x02 \x01(\x0e2E.mts.ai.audiogram.stt_response.v1.SpeakerGenderAgePrediction.AgeClass\x12a\n\x07emotion\x18\x03 \x01(\x0b2P.mts.ai.audiogram.stt_response.v1.SpeakerGenderAgePrediction.EmotionsRecognition\x1af\n\x13EmotionsRecognition\x12\x10\n\x08positive\x18\x01 \x01(\x02\x12\x0f\n\x07neutral\x18\x02 \x01(\x02\x12\x16\n\x0enegative_angry\x18\x03 \x01(\x02\x12\x14\n\x0cnegative_sad\x18\x04 \x01(\x02"C\n\x0bGenderClass\x12\x10\n\x0cGENDER_UNDEF\x10\x00\x12\x0f\n\x0bGENDER_MALE\x10\x01\x12\x11\n\rGENDER_FEMALE\x10\x02"7\n\x08AgeClass\x12\r\n\tAGE_UNDEF\x10\x00\x12\r\n\tAGE_ADULT\x10\x01\x12\r\n\tAGE_CHILD\x10\x02"\xd7\x01\n\x0eSpoofingResult\x12M\n\x06result\x18\x02 \x01(\x0e2=.mts.ai.audiogram.stt_response.v1.SpoofingResult.AttackResult\x12\x12\n\nconfidence\x18\x03 \x01(\x02\x12\x15\n\rstart_time_ms\x18\x04 \x01(\r\x12\x13\n\x0bend_time_ms\x18\x05 \x01(\r"0\n\x0cAttackResult\x12\x13\n\x0fATTACK_DETECTED\x10\x00\x12\x0b\n\x07GENUINE\x10\x01J\x04\x08\x01\x10\x02"!\n\x0bSpeakerInfo\x12\x12\n\nspeaker_id\x18\x01 \x01(\rb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'stt_response_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
    DESCRIPTOR._options = None
    _globals['_FILERECOGNIZERESPONSE']._serialized_start = 80
    _globals['_FILERECOGNIZERESPONSE']._serialized_end = 243
    _globals['_RECOGNIZERESPONSE']._serialized_start = 246
    _globals['_RECOGNIZERESPONSE']._serialized_end = 748
    _globals['_SPEECHRECOGNITIONHYPOTHESIS']._serialized_start = 751
    _globals['_SPEECHRECOGNITIONHYPOTHESIS']._serialized_end = 1170
    _globals['_SPEECHRECOGNITIONHYPOTHESIS_WORDINFO']._serialized_start = 1082
    _globals['_SPEECHRECOGNITIONHYPOTHESIS_WORDINFO']._serialized_end = 1170
    _globals['_VOICEACTIVITYMARK']._serialized_start = 1173
    _globals['_VOICEACTIVITYMARK']._serialized_end = 1384
    _globals['_VOICEACTIVITYMARK_VOICEACTIVITYMARKTYPE']._serialized_start = 1307
    _globals['_VOICEACTIVITYMARK_VOICEACTIVITYMARKTYPE']._serialized_end = 1384
    _globals['_SPEAKERGENDERAGEPREDICTION']._serialized_start = 1387
    _globals['_SPEAKERGENDERAGEPREDICTION']._serialized_end = 1918
    _globals['_SPEAKERGENDERAGEPREDICTION_EMOTIONSRECOGNITION']._serialized_start = 1690
    _globals['_SPEAKERGENDERAGEPREDICTION_EMOTIONSRECOGNITION']._serialized_end = 1792
    _globals['_SPEAKERGENDERAGEPREDICTION_GENDERCLASS']._serialized_start = 1794
    _globals['_SPEAKERGENDERAGEPREDICTION_GENDERCLASS']._serialized_end = 1861
    _globals['_SPEAKERGENDERAGEPREDICTION_AGECLASS']._serialized_start = 1863
    _globals['_SPEAKERGENDERAGEPREDICTION_AGECLASS']._serialized_end = 1918
    _globals['_SPOOFINGRESULT']._serialized_start = 1921
    _globals['_SPOOFINGRESULT']._serialized_end = 2136
    _globals['_SPOOFINGRESULT_ATTACKRESULT']._serialized_start = 2082
    _globals['_SPOOFINGRESULT_ATTACKRESULT']._serialized_end = 2130
    _globals['_SPEAKERINFO']._serialized_start = 2138
    _globals['_SPEAKERINFO']._serialized_end = 2171