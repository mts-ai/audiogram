"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_sym_db = _symbol_database.Default()
from . import stt_v3_pb2 as stt__v3__pb2
from . import longrunning_task_pb2 as longrunning__task__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x15longrunning_stt.proto\x12 mts.ai.audiogram.long_running.v1\x1a\x0cstt_v3.proto\x1a\x16longrunning_task.proto"\xf0\x01\n\x1bLongRunningRecognizeRequest\x12:\n\x06config\x18\x01 \x01(\x0b2*.mts.ai.audiogram.stt.v3.RecognitionConfig\x12^\n\rs3_audio_path\x18\x02 \x03(\x0b2G.mts.ai.audiogram.long_running.v1.LongRunningRecognizeRequest.AudioPath\x1a5\n\tAudioPath\x12\x13\n\x0bbucket_name\x18\x01 \x01(\t\x12\x13\n\x0bobject_name\x18\x02 \x01(\t2\xec\x02\n\x0bLongRunning\x12\x81\x01\n\x14LongRunningRecognize\x12=.mts.ai.audiogram.long_running.v1.LongRunningRecognizeRequest\x1a*.mts.ai.audiogram.longrunning_task.v1.Task\x12l\n\x0bGetTaskInfo\x121.mts.ai.audiogram.longrunning_task.v1.TaskRequest\x1a*.mts.ai.audiogram.longrunning_task.v1.Task\x12k\n\nCancelTask\x121.mts.ai.audiogram.longrunning_task.v1.TaskRequest\x1a*.mts.ai.audiogram.longrunning_task.v1.Taskb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'longrunning_stt_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
    DESCRIPTOR._options = None
    _globals['_LONGRUNNINGRECOGNIZEREQUEST']._serialized_start = 98
    _globals['_LONGRUNNINGRECOGNIZEREQUEST']._serialized_end = 338
    _globals['_LONGRUNNINGRECOGNIZEREQUEST_AUDIOPATH']._serialized_start = 285
    _globals['_LONGRUNNINGRECOGNIZEREQUEST_AUDIOPATH']._serialized_end = 338
    _globals['_LONGRUNNING']._serialized_start = 341
    _globals['_LONGRUNNING']._serialized_end = 705