"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_sym_db = _symbol_database.Default()
from google.protobuf import timestamp_pb2 as google_dot_protobuf_dot_timestamp__pb2
from . import stt_pb2 as stt__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x15longrunning_stt.proto\x12 mts.ai.audiogram.long_running.v1\x1a\x1fgoogle/protobuf/timestamp.proto\x1a\tstt.proto"\x9c\x02\n\x04Task\x12\n\n\x02id\x18\x01 \x01(\t\x12=\n\x06status\x18\x02 \x01(\x0e2-.mts.ai.audiogram.long_running.v1.Task.Status\x12.\n\ncreated_at\x18\x03 \x01(\x0b2\x1a.google.protobuf.Timestamp\x12?\n\x0eaudio_requests\x18\x04 \x03(\x0b2\'.mts.ai.audiogram.long_running.v1.Audio"X\n\x06Status\x12\r\n\tUNDEFINED\x10\x00\x12\x07\n\x03NEW\x10\x01\x12\x0f\n\x0bIN_PROGRESS\x10\x02\x12\x0c\n\x08COMPLETE\x10\x03\x12\x0c\n\x08CANCELED\x10\x04\x12\t\n\x05ERROR\x10\x05"V\n\x05Audio\x12\x13\n\x0bbucket_name\x18\x01 \x01(\t\x12\x13\n\x0bobject_name\x18\x02 \x01(\t\x12\x0e\n\x06status\x18\x03 \x01(\t\x12\x13\n\x0bresponse_id\x18\x04 \x01(\t"\x1e\n\x0bTaskRequest\x12\x0f\n\x07task_id\x18\x01 \x01(\t"\xf0\x01\n\x1bLongRunningRecognizeRequest\x12:\n\x06config\x18\x01 \x01(\x0b2*.mts.ai.audiogram.stt.v3.RecognitionConfig\x12^\n\rs3_audio_path\x18\x02 \x03(\x0b2G.mts.ai.audiogram.long_running.v1.LongRunningRecognizeRequest.AudioPath\x1a5\n\tAudioPath\x12\x13\n\x0bbucket_name\x18\x01 \x01(\t\x12\x13\n\x0bobject_name\x18\x02 \x01(\t2\xd7\x02\n\x0bLongRunning\x12}\n\x14LongRunningRecognize\x12=.mts.ai.audiogram.long_running.v1.LongRunningRecognizeRequest\x1a&.mts.ai.audiogram.long_running.v1.Task\x12d\n\x0bGetTaskInfo\x12-.mts.ai.audiogram.long_running.v1.TaskRequest\x1a&.mts.ai.audiogram.long_running.v1.Task\x12c\n\nCancelTask\x12-.mts.ai.audiogram.long_running.v1.TaskRequest\x1a&.mts.ai.audiogram.long_running.v1.Taskb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'longrunning_stt_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
    DESCRIPTOR._options = None
    _globals['_TASK']._serialized_start = 104
    _globals['_TASK']._serialized_end = 388
    _globals['_TASK_STATUS']._serialized_start = 300
    _globals['_TASK_STATUS']._serialized_end = 388
    _globals['_AUDIO']._serialized_start = 390
    _globals['_AUDIO']._serialized_end = 476
    _globals['_TASKREQUEST']._serialized_start = 478
    _globals['_TASKREQUEST']._serialized_end = 508
    _globals['_LONGRUNNINGRECOGNIZEREQUEST']._serialized_start = 511
    _globals['_LONGRUNNINGRECOGNIZEREQUEST']._serialized_end = 751
    _globals['_LONGRUNNINGRECOGNIZEREQUEST_AUDIOPATH']._serialized_start = 698
    _globals['_LONGRUNNINGRECOGNIZEREQUEST_AUDIOPATH']._serialized_end = 751
    _globals['_LONGRUNNING']._serialized_start = 754
    _globals['_LONGRUNNING']._serialized_end = 1097