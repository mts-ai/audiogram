"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_sym_db = _symbol_database.Default()
from . import response_header_pb2 as response__header__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x11tts_presets.proto\x12\x1fmts.ai.audiogram.tts_presets.v2\x1a\x15response_header.proto"5\n\x06Preset\x12\x13\n\x0bpreset_name\x18\x01 \x01(\t\x12\x16\n\x0epreset_version\x18\x02 \x01(\x05"\x82\x01\n\x17SynthesizeSpeechRequest\x12\x0e\n\x04text\x18\x01 \x01(\tH\x00\x12\x0e\n\x04ssml\x18\x02 \x01(\tH\x00\x127\n\x06preset\x18\x03 \x01(\x0b2\'.mts.ai.audiogram.tts_presets.v2.PresetB\x0e\n\x0cinput_source"w\n!StreamingSynthesizeSpeechResponse\x12\r\n\x05audio\x18\x01 \x01(\x0c\x12C\n\x06header\x18\x02 \x01(\x0b23.mts.ai.audiogram.response_header.v1.ResponseHeader"n\n\x18SynthesizeSpeechResponse\x12\r\n\x05audio\x18\x01 \x01(\x0c\x12C\n\x06header\x18\x02 \x01(\x0b23.mts.ai.audiogram.response_header.v1.ResponseHeader2\xa1\x02\n\x03TTS\x12\x95\x01\n\x13StreamingSynthesize\x128.mts.ai.audiogram.tts_presets.v2.SynthesizeSpeechRequest\x1aB.mts.ai.audiogram.tts_presets.v2.StreamingSynthesizeSpeechResponse0\x01\x12\x81\x01\n\nSynthesize\x128.mts.ai.audiogram.tts_presets.v2.SynthesizeSpeechRequest\x1a9.mts.ai.audiogram.tts_presets.v2.SynthesizeSpeechResponseb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'tts_presets_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
    DESCRIPTOR._options = None
    _globals['_PRESET']._serialized_start = 77
    _globals['_PRESET']._serialized_end = 130
    _globals['_SYNTHESIZESPEECHREQUEST']._serialized_start = 133
    _globals['_SYNTHESIZESPEECHREQUEST']._serialized_end = 263
    _globals['_STREAMINGSYNTHESIZESPEECHRESPONSE']._serialized_start = 265
    _globals['_STREAMINGSYNTHESIZESPEECHRESPONSE']._serialized_end = 384
    _globals['_SYNTHESIZESPEECHRESPONSE']._serialized_start = 386
    _globals['_SYNTHESIZESPEECHRESPONSE']._serialized_end = 496
    _globals['_TTS']._serialized_start = 499
    _globals['_TTS']._serialized_end = 788