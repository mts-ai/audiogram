"""Client and server classes corresponding to protobuf-defined services."""
import grpc
from . import longrunning_stt_pb2 as longrunning__stt__pb2
from . import longrunning_task_pb2 as longrunning__task__pb2

class LongRunningStub(object):
    """Missing associated documentation comment in .proto file."""

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.LongRunningRecognize = channel.unary_unary('/mts.ai.audiogram.long_running.v1.LongRunning/LongRunningRecognize', request_serializer=longrunning__stt__pb2.LongRunningRecognizeRequest.SerializeToString, response_deserializer=longrunning__task__pb2.Task.FromString)
        self.GetTaskInfo = channel.unary_unary('/mts.ai.audiogram.long_running.v1.LongRunning/GetTaskInfo', request_serializer=longrunning__task__pb2.TaskRequest.SerializeToString, response_deserializer=longrunning__task__pb2.Task.FromString)
        self.CancelTask = channel.unary_unary('/mts.ai.audiogram.long_running.v1.LongRunning/CancelTask', request_serializer=longrunning__task__pb2.TaskRequest.SerializeToString, response_deserializer=longrunning__task__pb2.Task.FromString)

class LongRunningServicer(object):
    """Missing associated documentation comment in .proto file."""

    def LongRunningRecognize(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def GetTaskInfo(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def CancelTask(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_LongRunningServicer_to_server(servicer, server):
    rpc_method_handlers = {'LongRunningRecognize': grpc.unary_unary_rpc_method_handler(servicer.LongRunningRecognize, request_deserializer=longrunning__stt__pb2.LongRunningRecognizeRequest.FromString, response_serializer=longrunning__task__pb2.Task.SerializeToString), 'GetTaskInfo': grpc.unary_unary_rpc_method_handler(servicer.GetTaskInfo, request_deserializer=longrunning__task__pb2.TaskRequest.FromString, response_serializer=longrunning__task__pb2.Task.SerializeToString), 'CancelTask': grpc.unary_unary_rpc_method_handler(servicer.CancelTask, request_deserializer=longrunning__task__pb2.TaskRequest.FromString, response_serializer=longrunning__task__pb2.Task.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('mts.ai.audiogram.long_running.v1.LongRunning', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))

class LongRunning(object):
    """Missing associated documentation comment in .proto file."""

    @staticmethod
    def LongRunningRecognize(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/mts.ai.audiogram.long_running.v1.LongRunning/LongRunningRecognize', longrunning__stt__pb2.LongRunningRecognizeRequest.SerializeToString, longrunning__task__pb2.Task.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata)

    @staticmethod
    def GetTaskInfo(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/mts.ai.audiogram.long_running.v1.LongRunning/GetTaskInfo', longrunning__task__pb2.TaskRequest.SerializeToString, longrunning__task__pb2.Task.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata)

    @staticmethod
    def CancelTask(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/mts.ai.audiogram.long_running.v1.LongRunning/CancelTask', longrunning__task__pb2.TaskRequest.SerializeToString, longrunning__task__pb2.Task.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata)