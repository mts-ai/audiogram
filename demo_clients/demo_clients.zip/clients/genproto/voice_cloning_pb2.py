"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_sym_db = _symbol_database.Default()
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x13voice_cloning.proto\x12!mts.ai.audiogram.voice_cloning.v1\x1a\x1bgoogle/protobuf/empty.proto"\x9d\x01\n\x08TaskInfo\x12\x10\n\x08voice_id\x18\x01 \x01(\t\x12B\n\x06status\x18\x02 \x01(\x0e22.mts.ai.audiogram.voice_cloning.v1.TaskInfo.Status";\n\x06Status\x12\r\n\tUNDEFINED\x10\x00\x12\x0c\n\x08CREATING\x10\x01\x12\t\n\x05READY\x10\x02\x12\t\n\x05ERROR\x10\x03")\n\x11CloneVoiceRequest\x12\x0e\n\x06signal\x18\x02 \x01(\x0cJ\x04\x08\x01\x10\x02"\x15\n\x06TaskId\x12\x0b\n\x03val\x18\x01 \x01(\t"&\n\x12DeleteVoiceRequest\x12\x10\n\x08voice_id\x18\x01 \x01(\t2\xc2\x02\n\x0cVoiceCloning\x12m\n\nCloneVoice\x124.mts.ai.audiogram.voice_cloning.v1.CloneVoiceRequest\x1a).mts.ai.audiogram.voice_cloning.v1.TaskId\x12e\n\x0bGetTaskInfo\x12).mts.ai.audiogram.voice_cloning.v1.TaskId\x1a+.mts.ai.audiogram.voice_cloning.v1.TaskInfo\x12\\\n\x0bDeleteVoice\x125.mts.ai.audiogram.voice_cloning.v1.DeleteVoiceRequest\x1a\x16.google.protobuf.Emptyb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'voice_cloning_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
    DESCRIPTOR._options = None
    _globals['_TASKINFO']._serialized_start = 88
    _globals['_TASKINFO']._serialized_end = 245
    _globals['_TASKINFO_STATUS']._serialized_start = 186
    _globals['_TASKINFO_STATUS']._serialized_end = 245
    _globals['_CLONEVOICEREQUEST']._serialized_start = 247
    _globals['_CLONEVOICEREQUEST']._serialized_end = 288
    _globals['_TASKID']._serialized_start = 290
    _globals['_TASKID']._serialized_end = 311
    _globals['_DELETEVOICEREQUEST']._serialized_start = 313
    _globals['_DELETEVOICEREQUEST']._serialized_end = 351
    _globals['_VOICECLONING']._serialized_start = 354
    _globals['_VOICECLONING']._serialized_end = 676