"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_sym_db = _symbol_database.Default()
from . import stt_response_pb2 as stt__response__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x11stt_presets.proto\x12\x1fmts.ai.audiogram.stt_presets.v2\x1a\x12stt_response.proto"5\n\x06Preset\x12\x13\n\x0bpreset_name\x18\x01 \x01(\t\x12\x16\n\x0epreset_version\x18\x02 \x01(\x05"^\n\x14FileRecognizeRequest\x127\n\x06preset\x18\x01 \x01(\x0b2\'.mts.ai.audiogram.stt_presets.v2.Preset\x12\r\n\x05audio\x18\x02 \x01(\x0c"s\n\x10RecognizeRequest\x129\n\x06preset\x18\x01 \x01(\x0b2\'.mts.ai.audiogram.stt_presets.v2.PresetH\x00\x12\x0f\n\x05audio\x18\x02 \x01(\x0cH\x00B\x13\n\x11streaming_request2\xff\x01\n\x03STT\x12\x7f\n\rFileRecognize\x125.mts.ai.audiogram.stt_presets.v2.FileRecognizeRequest\x1a7.mts.ai.audiogram.stt_response.v1.FileRecognizeResponse\x12w\n\tRecognize\x121.mts.ai.audiogram.stt_presets.v2.RecognizeRequest\x1a3.mts.ai.audiogram.stt_response.v1.RecognizeResponse(\x010\x01b\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'stt_presets_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
    DESCRIPTOR._options = None
    _globals['_PRESET']._serialized_start = 74
    _globals['_PRESET']._serialized_end = 127
    _globals['_FILERECOGNIZEREQUEST']._serialized_start = 129
    _globals['_FILERECOGNIZEREQUEST']._serialized_end = 223
    _globals['_RECOGNIZEREQUEST']._serialized_start = 225
    _globals['_RECOGNIZEREQUEST']._serialized_end = 340
    _globals['_STT']._serialized_start = 343
    _globals['_STT']._serialized_end = 598