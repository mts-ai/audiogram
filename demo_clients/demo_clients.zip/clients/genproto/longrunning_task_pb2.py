"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_sym_db = _symbol_database.Default()
from google.protobuf import timestamp_pb2 as google_dot_protobuf_dot_timestamp__pb2
from . import response_header_pb2 as response__header__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x16longrunning_task.proto\x12$mts.ai.audiogram.longrunning_task.v1\x1a\x1fgoogle/protobuf/timestamp.proto\x1a\x15response_header.proto"\xe9\x02\n\x04Task\x12\n\n\x02id\x18\x01 \x01(\t\x12A\n\x06status\x18\x02 \x01(\x0e21.mts.ai.audiogram.longrunning_task.v1.Task.Status\x12.\n\ncreated_at\x18\x03 \x01(\x0b2\x1a.google.protobuf.Timestamp\x12C\n\x0eaudio_requests\x18\x04 \x03(\x0b2+.mts.ai.audiogram.longrunning_task.v1.Audio\x12C\n\x06header\x18\x05 \x01(\x0b23.mts.ai.audiogram.response_header.v1.ResponseHeader"X\n\x06Status\x12\r\n\tUNDEFINED\x10\x00\x12\x07\n\x03NEW\x10\x01\x12\x0f\n\x0bIN_PROGRESS\x10\x02\x12\x0c\n\x08COMPLETE\x10\x03\x12\x0c\n\x08CANCELED\x10\x04\x12\t\n\x05ERROR\x10\x05"V\n\x05Audio\x12\x13\n\x0bbucket_name\x18\x01 \x01(\t\x12\x13\n\x0bobject_name\x18\x02 \x01(\t\x12\x0e\n\x06status\x18\x03 \x01(\t\x12\x13\n\x0bresponse_id\x18\x04 \x01(\t"\x1e\n\x0bTaskRequest\x12\x0f\n\x07task_id\x18\x01 \x01(\tb\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'longrunning_task_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
    DESCRIPTOR._options = None
    _globals['_TASK']._serialized_start = 121
    _globals['_TASK']._serialized_end = 482
    _globals['_TASK_STATUS']._serialized_start = 394
    _globals['_TASK_STATUS']._serialized_end = 482
    _globals['_AUDIO']._serialized_start = 484
    _globals['_AUDIO']._serialized_end = 570
    _globals['_TASKREQUEST']._serialized_start = 572
    _globals['_TASKREQUEST']._serialized_end = 602