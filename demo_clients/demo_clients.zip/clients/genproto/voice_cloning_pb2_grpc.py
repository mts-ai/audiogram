"""Client and server classes corresponding to protobuf-defined services."""
import grpc
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2
from . import voice_cloning_pb2 as voice__cloning__pb2

class VoiceCloningStub(object):
    """Missing associated documentation comment in .proto file."""

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.CloneVoice = channel.unary_unary('/mts.ai.audiogram.voice_cloning.v1.VoiceCloning/CloneVoice', request_serializer=voice__cloning__pb2.CloneVoiceRequest.SerializeToString, response_deserializer=voice__cloning__pb2.TaskId.FromString)
        self.GetTaskInfo = channel.unary_unary('/mts.ai.audiogram.voice_cloning.v1.VoiceCloning/GetTaskInfo', request_serializer=voice__cloning__pb2.TaskId.SerializeToString, response_deserializer=voice__cloning__pb2.TaskInfo.FromString)
        self.DeleteVoice = channel.unary_unary('/mts.ai.audiogram.voice_cloning.v1.VoiceCloning/DeleteVoice', request_serializer=voice__cloning__pb2.DeleteVoiceRequest.SerializeToString, response_deserializer=google_dot_protobuf_dot_empty__pb2.Empty.FromString)

class VoiceCloningServicer(object):
    """Missing associated documentation comment in .proto file."""

    def CloneVoice(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def GetTaskInfo(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def DeleteVoice(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_VoiceCloningServicer_to_server(servicer, server):
    rpc_method_handlers = {'CloneVoice': grpc.unary_unary_rpc_method_handler(servicer.CloneVoice, request_deserializer=voice__cloning__pb2.CloneVoiceRequest.FromString, response_serializer=voice__cloning__pb2.TaskId.SerializeToString), 'GetTaskInfo': grpc.unary_unary_rpc_method_handler(servicer.GetTaskInfo, request_deserializer=voice__cloning__pb2.TaskId.FromString, response_serializer=voice__cloning__pb2.TaskInfo.SerializeToString), 'DeleteVoice': grpc.unary_unary_rpc_method_handler(servicer.DeleteVoice, request_deserializer=voice__cloning__pb2.DeleteVoiceRequest.FromString, response_serializer=google_dot_protobuf_dot_empty__pb2.Empty.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('mts.ai.audiogram.voice_cloning.v1.VoiceCloning', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))

class VoiceCloning(object):
    """Missing associated documentation comment in .proto file."""

    @staticmethod
    def CloneVoice(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/mts.ai.audiogram.voice_cloning.v1.VoiceCloning/CloneVoice', voice__cloning__pb2.CloneVoiceRequest.SerializeToString, voice__cloning__pb2.TaskId.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata)

    @staticmethod
    def GetTaskInfo(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/mts.ai.audiogram.voice_cloning.v1.VoiceCloning/GetTaskInfo', voice__cloning__pb2.TaskId.SerializeToString, voice__cloning__pb2.TaskInfo.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata)

    @staticmethod
    def DeleteVoice(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/mts.ai.audiogram.voice_cloning.v1.VoiceCloning/DeleteVoice', voice__cloning__pb2.DeleteVoiceRequest.SerializeToString, google_dot_protobuf_dot_empty__pb2.Empty.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata)