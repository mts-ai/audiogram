"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_sym_db = _symbol_database.Default()
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2
from . import response_header_pb2 as response__header__pb2
from . import stt_response_pb2 as stt__response__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x0cstt_v3.proto\x12\x17mts.ai.audiogram.stt.v3\x1a\x1bgoogle/protobuf/empty.proto\x1a\x15response_header.proto\x1a\x12stt_response.proto"a\n\x14FileRecognizeRequest\x12:\n\x06config\x18\x01 \x01(\x0b2*.mts.ai.audiogram.stt.v3.RecognitionConfig\x12\r\n\x05audio\x18\x02 \x01(\x0c"|\n\x10RecognizeRequest\x12B\n\x06config\x18\x01 \x01(\x0b20.mts.ai.audiogram.stt.v3.StreamRecognitionConfigH\x00\x12\x0f\n\x05audio\x18\x02 \x01(\x0cH\x00B\x13\n\x11streaming_request"b\n\x1cSubstitutionDictionaryConfig\x12\x19\n\x0fdictionary_name\x18\x01 \x01(\tH\x00\x12\x19\n\x0fdictionary_data\x18\x02 \x01(\tH\x00B\x0c\n\ndictionary"\x88\x08\n\x11RecognitionConfig\x128\n\x08encoding\x18\x01 \x01(\x0e2&.mts.ai.audiogram.stt.v3.AudioEncoding\x12\x19\n\x11sample_rate_hertz\x18\x02 \x01(\r\x12\x15\n\rlanguage_code\x18\x03 \x01(\t\x12\x1b\n\x13audio_channel_count\x18\x04 \x01(\r\x12\x18\n\x10split_by_channel\x18\x05 \x01(\x08\x12\r\n\x05model\x18\x06 \x01(\t\x12 \n\x18enable_word_time_offsets\x18\x07 \x01(\x08\x12?\n\tva_config\x18\x08 \x01(\x0b2,.mts.ai.audiogram.stt.v3.VoiceActivityConfig\x12`\n\x10va_response_mode\x18\t \x01(\x0e2F.mts.ai.audiogram.stt.v3.RecognitionConfig.VoiceActivityMarkEventsMode\x12I\n\x10genderage_config\x18\n \x01(\x0b2/.mts.ai.audiogram.stt.v3.GenderAgeEmotionConfig\x12H\n\x13antispoofing_config\x18\x0b \x01(\x0b2+.mts.ai.audiogram.stt.v3.AntiSpoofingConfig\x12L\n\x12context_dictionary\x18\x0c \x01(\x0b20.mts.ai.audiogram.stt.v3.ContextDictionaryConfig\x12F\n\x12punctuation_config\x18\r \x01(\x0b2*.mts.ai.audiogram.stt.v3.PunctuationConfig\x12N\n\x16denormalization_config\x18\x0e \x01(\x0b2..mts.ai.audiogram.stt.v3.DenormalizationConfig\x12O\n\x17speaker_labeling_config\x18\x0f \x01(\x0b2..mts.ai.audiogram.stt.v3.SpeakerLabelingConfig\x12]\n\x1esubstitution_dictionary_config\x18\x10 \x01(\x0b25.mts.ai.audiogram.stt.v3.SubstitutionDictionaryConfig"Q\n\x1bVoiceActivityMarkEventsMode\x12\x0e\n\nVA_DISABLE\x10\x00\x12\r\n\tVA_ENABLE\x10\x01\x12\x13\n\x0fVA_ENABLE_ASYNC\x10\x02"\x88\x01\n\x17StreamRecognitionConfig\x12:\n\x06config\x18\x01 \x01(\x0b2*.mts.ai.audiogram.stt.v3.RecognitionConfig\x12\x18\n\x10single_utterance\x18\x02 \x01(\x08\x12\x17\n\x0finterim_results\x18\x03 \x01(\x08"\xb9\x04\n\x13VoiceActivityConfig\x12`\n\x05usage\x18\x01 \x01(\x0e2Q.mts.ai.audiogram.stt.v3.VoiceActivityConfig.VoiceActivityDetectionAlgorithmUsage\x12:\n\x0bvad_options\x18\x02 \x01(\x0b2#.mts.ai.audiogram.stt.v3.VADOptionsH\x00\x12:\n\x0bdep_options\x18\x03 \x01(\x0b2#.mts.ai.audiogram.stt.v3.DEPOptionsH\x00\x12K\n\x14enhanced_vad_options\x18\x04 \x01(\x0b2+.mts.ai.audiogram.stt.v3.EnhancedVADOptionsH\x00\x12T\n\x19target_speech_vad_options\x18\x05 \x01(\x0b2/.mts.ai.audiogram.stt.v3.TargetSpeechVADOptionsH\x00"\x94\x01\n$VoiceActivityDetectionAlgorithmUsage\x12\x0b\n\x07USE_VAD\x10\x00\x12!\n\x1dDO_NOT_PERFORM_VOICE_ACTIVITY\x10\x01\x12\x0b\n\x07USE_DEP\x10\x02\x12\x14\n\x10USE_ENHANCED_VAD\x10\x03\x12\x19\n\x15USE_TARGET_SPEECH_VAD\x10\x04B\x0e\n\x0calgo_options"\x8d\x02\n\nVADOptions\x12\x11\n\tthreshold\x18\x01 \x01(\x02\x12\x15\n\rspeech_pad_ms\x18\x02 \x01(\x05\x12\x16\n\x0emin_silence_ms\x18\x03 \x01(\r\x12\x15\n\rmin_speech_ms\x18\x04 \x01(\r\x12L\n\x04mode\x18\x05 \x01(\x0e2>.mts.ai.audiogram.stt.v3.VADOptions.VoiceActivityDetectionMode"X\n\x1aVoiceActivityDetectionMode\x12\x14\n\x10VAD_MODE_DEFAULT\x10\x00\x12\x13\n\x0fSPLIT_BY_PAUSES\x10\x01\x12\x0f\n\x0bONLY_SPEECH\x10\x02"K\n\nDEPOptions\x12!\n\x19smoothed_window_threshold\x18\x01 \x01(\x02\x12\x1a\n\x12smoothed_window_ms\x18\x02 \x01(\x05"\x82\x01\n\x12EnhancedVADOptions\x12\x1b\n\x13beginning_window_ms\x18\x01 \x01(\x05\x12\x1b\n\x13beginning_threshold\x18\x02 \x01(\x02\x12\x18\n\x10ending_window_ms\x18\x03 \x01(\x05\x12\x18\n\x10ending_threshold\x18\x04 \x01(\x02"\x86\x01\n\x16TargetSpeechVADOptions\x12\x1b\n\x13beginning_window_ms\x18\x01 \x01(\x05\x12\x1b\n\x13beginning_threshold\x18\x02 \x01(\x02\x12\x18\n\x10ending_window_ms\x18\x03 \x01(\x05\x12\x18\n\x10ending_threshold\x18\x04 \x01(\x02"(\n\x16GenderAgeEmotionConfig\x12\x0e\n\x06enable\x18\x01 \x01(\x08"\x81\x01\n\x12AntiSpoofingConfig\x12\r\n\x03FAR\x18\x02 \x01(\x02H\x00\x12\r\n\x03FRR\x18\x03 \x01(\x02H\x00\x12$\n\x1cmax_duration_for_analysis_ms\x18\x04 \x01(\r\x12\x0e\n\x06enable\x18\x05 \x01(\x08B\x11\n\x0ffalse_rate_typeJ\x04\x08\x01\x10\x02"B\n\x17ContextDictionaryConfig\x12\x17\n\x0fdictionary_name\x18\x01 \x01(\t\x12\x0e\n\x06weight\x18\x02 \x01(\x02"#\n\x11PunctuationConfig\x12\x0e\n\x06enable\x18\x01 \x01(\x08"\'\n\x15DenormalizationConfig\x12\x0e\n\x06enable\x18\x01 \x01(\x08"c\n\x15SpeakerLabelingConfig\x12\x0e\n\x06enable\x18\x01 \x01(\x08\x12\x16\n\x0cmax_speakers\x18\x02 \x01(\rH\x00\x12\x16\n\x0cnum_speakers\x18\x03 \x01(\rH\x00B\n\n\x08speakers"\x85\x01\n\nModelsInfo\x122\n\x06models\x18\x01 \x03(\x0b2".mts.ai.audiogram.stt.v3.ModelInfo\x12C\n\x06header\x18\x02 \x01(\x0b23.mts.ai.audiogram.response_header.v1.ResponseHeader"d\n\tModelInfo\x12\x0c\n\x04name\x18\x01 \x01(\t\x12\x19\n\x11sample_rate_hertz\x18\x02 \x01(\r\x12\x15\n\rlanguage_code\x18\x03 \x01(\t\x12\x17\n\x0fdictionary_name\x18\x04 \x03(\t*X\n\rAudioEncoding\x12\x18\n\x14ENCODING_UNSPECIFIED\x10\x00\x12\x0e\n\nLINEAR_PCM\x10\x01\x12\x08\n\x04FLAC\x10\x02\x12\t\n\x05MULAW\x10\x03\x12\x08\n\x04ALAW\x10\x142\xbd\x02\n\x03STT\x12w\n\rFileRecognize\x12-.mts.ai.audiogram.stt.v3.FileRecognizeRequest\x1a7.mts.ai.audiogram.stt_response.v1.FileRecognizeResponse\x12o\n\tRecognize\x12).mts.ai.audiogram.stt.v3.RecognizeRequest\x1a3.mts.ai.audiogram.stt_response.v1.RecognizeResponse(\x010\x01\x12L\n\rGetModelsInfo\x12\x16.google.protobuf.Empty\x1a#.mts.ai.audiogram.stt.v3.ModelsInfob\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'stt_v3_pb2', _globals)
if _descriptor._USE_C_DESCRIPTORS == False:
    DESCRIPTOR._options = None
    _globals['_AUDIOENCODING']._serialized_start = 3462
    _globals['_AUDIOENCODING']._serialized_end = 3550
    _globals['_FILERECOGNIZEREQUEST']._serialized_start = 113
    _globals['_FILERECOGNIZEREQUEST']._serialized_end = 210
    _globals['_RECOGNIZEREQUEST']._serialized_start = 212
    _globals['_RECOGNIZEREQUEST']._serialized_end = 336
    _globals['_SUBSTITUTIONDICTIONARYCONFIG']._serialized_start = 338
    _globals['_SUBSTITUTIONDICTIONARYCONFIG']._serialized_end = 436
    _globals['_RECOGNITIONCONFIG']._serialized_start = 439
    _globals['_RECOGNITIONCONFIG']._serialized_end = 1471
    _globals['_RECOGNITIONCONFIG_VOICEACTIVITYMARKEVENTSMODE']._serialized_start = 1390
    _globals['_RECOGNITIONCONFIG_VOICEACTIVITYMARKEVENTSMODE']._serialized_end = 1471
    _globals['_STREAMRECOGNITIONCONFIG']._serialized_start = 1474
    _globals['_STREAMRECOGNITIONCONFIG']._serialized_end = 1610
    _globals['_VOICEACTIVITYCONFIG']._serialized_start = 1613
    _globals['_VOICEACTIVITYCONFIG']._serialized_end = 2182
    _globals['_VOICEACTIVITYCONFIG_VOICEACTIVITYDETECTIONALGORITHMUSAGE']._serialized_start = 2018
    _globals['_VOICEACTIVITYCONFIG_VOICEACTIVITYDETECTIONALGORITHMUSAGE']._serialized_end = 2166
    _globals['_VADOPTIONS']._serialized_start = 2185
    _globals['_VADOPTIONS']._serialized_end = 2454
    _globals['_VADOPTIONS_VOICEACTIVITYDETECTIONMODE']._serialized_start = 2366
    _globals['_VADOPTIONS_VOICEACTIVITYDETECTIONMODE']._serialized_end = 2454
    _globals['_DEPOPTIONS']._serialized_start = 2456
    _globals['_DEPOPTIONS']._serialized_end = 2531
    _globals['_ENHANCEDVADOPTIONS']._serialized_start = 2534
    _globals['_ENHANCEDVADOPTIONS']._serialized_end = 2664
    _globals['_TARGETSPEECHVADOPTIONS']._serialized_start = 2667
    _globals['_TARGETSPEECHVADOPTIONS']._serialized_end = 2801
    _globals['_GENDERAGEEMOTIONCONFIG']._serialized_start = 2803
    _globals['_GENDERAGEEMOTIONCONFIG']._serialized_end = 2843
    _globals['_ANTISPOOFINGCONFIG']._serialized_start = 2846
    _globals['_ANTISPOOFINGCONFIG']._serialized_end = 2975
    _globals['_CONTEXTDICTIONARYCONFIG']._serialized_start = 2977
    _globals['_CONTEXTDICTIONARYCONFIG']._serialized_end = 3043
    _globals['_PUNCTUATIONCONFIG']._serialized_start = 3045
    _globals['_PUNCTUATIONCONFIG']._serialized_end = 3080
    _globals['_DENORMALIZATIONCONFIG']._serialized_start = 3082
    _globals['_DENORMALIZATIONCONFIG']._serialized_end = 3121
    _globals['_SPEAKERLABELINGCONFIG']._serialized_start = 3123
    _globals['_SPEAKERLABELINGCONFIG']._serialized_end = 3222
    _globals['_MODELSINFO']._serialized_start = 3225
    _globals['_MODELSINFO']._serialized_end = 3358
    _globals['_MODELINFO']._serialized_start = 3360
    _globals['_MODELINFO']._serialized_end = 3460
    _globals['_STT']._serialized_start = 3553
    _globals['_STT']._serialized_end = 3870