import click

from .preset_synthesize_cmd import preset_stream_synthesize, preset_synthesize


@click.group(help="Speech synthesis clients that use presets")
def preset_synthesize_group() -> None:
    pass


preset_synthesize_group.add_command(preset_synthesize, "file")
preset_synthesize_group.add_command(preset_stream_synthesize, "stream")
