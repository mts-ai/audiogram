from pathlib import Path

import click
import grpc

from clients.common_utils.arguments import common_options_in_settings
from clients.common_utils.auth import get_auth_metadata
from clients.common_utils.config import SettingsProtocol
from clients.common_utils.errors import errors_handler
from clients.common_utils.grpc import (
    get_extra_metadata,
    open_grpc_channel,
    print_metadata,
    ssl_creds_from_settings,
)
from clients.genproto import tts_presets_pb2, tts_presets_pb2_grpc


@click.command(
    no_args_is_help=True,
    help="Offline (file) speech synthesis using preset configuration",
)
@errors_handler
@common_options_in_settings
@click.option(
    "--preset-name",
    required=True,
    help="name of the preset to use",
)
@click.option(
    "--preset-version",
    type=int,
    required=True,
    help="version of the preset to use",
)
@click.option(
    "--text",
    required=True,
    help="text or SSML (if --read-ssml enabled) for speech synthesis",
    metavar="<text>",
)
@click.option(
    "--read-ssml",
    "is_ssml",
    is_flag=True,
    default=False,
    help="process --text as SSML (with speech markup)",
)
@click.option(
    "--save-to",
    "output_file",
    type=click.Path(file_okay=True, dir_okay=False, writable=True),
    default="synthesized_audio.wav",
    help="output audio file path",
    metavar="<file path>",
    show_default=True,
)
def preset_synthesize(
    settings: SettingsProtocol,
    preset_name: str,
    preset_version: int,
    text: str,
    is_ssml: bool,
    output_file: str,
) -> None:
    auth_metadata = get_auth_metadata(
        settings.sso_url,
        settings.realm,
        settings.client_id,
        settings.client_secret,
        settings.iam_account,
        settings.iam_workspace,
        settings.verify_sso,
    )
    metadata = (*auth_metadata, *get_extra_metadata(settings))

    click.echo(
        f"Request parameters:\n"
        f"Interpret text as SSML: {is_ssml}\n"
        f"Preset name: {preset_name}\n"
        f"Preset version: {preset_version}\n"
    )

    preset_config = tts_presets_pb2.Preset(
        preset_name=preset_name,
        preset_version=preset_version,
    )
    request = tts_presets_pb2.SynthesizeSpeechRequest(
        preset=preset_config,
    )

    if is_ssml:
        request.ssml = text
    else:
        request.text = text

    click.echo(f"Connecting to gRPC server - {settings.api_address}\n")

    with open_grpc_channel(
        settings.api_address,
        ssl_creds_from_settings(settings),
    ) as channel:
        stub = tts_presets_pb2_grpc.TTSStub(channel)

        response: tts_presets_pb2.SynthesizeSpeechResponse
        call: grpc.Call
        response, call = stub.Synthesize.with_call(
            request,
            metadata=metadata,
            timeout=settings.timeout,
        )

        click.echo("Response metadata:")
        print_metadata(call.initial_metadata())
        click.echo()

    click.echo(f"Received audio size: {len(response.audio)}")

    # NB (k.zhovnovatiy): Received audio already contains WAV headers, so just write it
    Path(output_file).write_bytes(response.audio)
    click.echo(f"Synthesized audio stored in {output_file}")
