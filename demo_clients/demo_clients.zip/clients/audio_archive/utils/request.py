from pathlib import Path

import click
import pydantic
import requests
import urllib3

from clients.audio_archive.utils.models import RequestsList


def try_request(
    url: str, verify: bool = True, ca_cert_bundle_path: Path | None = None
) -> requests.Response:
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    verify_arg: str | bool = False

    if verify and ca_cert_bundle_path is not None:
        verify_arg = str(ca_cert_bundle_path)

    try:
        return requests.get(
            url,
            # verify=False disables SSL certificate verification completely
            # verify='path/to/ca_cert_bundle.pem' sets CA certificate bundle to use for verification
            verify=verify_arg,
        )
    except requests.ConnectionError as e:
        click.echo(f"Connection error: {e}")
        context = click.get_current_context()
        context.exit(-1)


def fetch_trace_and_session_id(
    api_address: str,
    client_id: str,
    request_id: str,
) -> tuple[str | None, str | None]:
    url = "https://" + api_address + f"/clients/{client_id}/requests"

    resp = try_request(url)

    if resp.status_code != 200:
        click.echo("Unable to fetch session and trace ids for this request")
        return None, None

    resp_json = resp.json()

    try:
        req_list = RequestsList(**resp_json)
    except pydantic.ValidationError as e:
        click.echo(f"Unable to find session and trace ids for this request: {e.errors()}")
        return None, None

    for item in req_list.data:
        if item.request_id != request_id:
            continue

        return item.trace_id, item.session_id

    return None, None
