from typing import Final

import click
import grpc

from clients.common_utils.arguments import common_options_in_settings
from clients.common_utils.audio import AudioFile
from clients.common_utils.auth import get_auth_metadata
from clients.common_utils.config import SettingsProtocol
from clients.common_utils.errors import errors_handler
from clients.common_utils.grpc import (
    get_extra_metadata,
    open_grpc_channel,
    print_metadata,
    ssl_creds_from_settings,
)
from clients.genproto import stt_v3_pb2, voice_cloning_pb2, voice_cloning_pb2_grpc

AUDIO_ENCODING: Final = stt_v3_pb2.AudioEncoding.LINEAR_PCM


@click.command(
    no_args_is_help=True,
    help="Clone voice",
)
@errors_handler
@common_options_in_settings
@click.option(
    "--audio-file",
    type=click.Path(file_okay=True, dir_okay=False, readable=True),
    help="audio file path (required)",
    metavar="<.wav path>",
    required=True,
)
def clone_voice(
    settings: SettingsProtocol,
    audio_file: str,
) -> None:
    auth_metadata = get_auth_metadata(
        settings.sso_url,
        settings.realm,
        settings.client_id,
        settings.client_secret,
        settings.iam_account,
        settings.iam_workspace,
        settings.verify_sso,
    )
    metadata = (*auth_metadata, *get_extra_metadata(settings))

    audio = AudioFile(audio_file)

    click.echo(
        f"Request parameters:\n"
        f"Audio file: {audio_file}\n"
        f"Audio sample rate: {audio.sample_rate}\n"
        f"Audio channels: {audio.channel_count}\n"
    )

    audio_format_config = voice_cloning_pb2.AudioFormat(
        encoding=AUDIO_ENCODING,
        sample_rate_hertz=audio.sample_rate,
        audio_channel_count=audio.channel_count,
    )
    request = voice_cloning_pb2.CloneVoiceRequest(
        audio_format=audio_format_config,
        signal=audio.blob,
    )

    click.echo(f"Connecting to gRPC server - {settings.api_address}\n")
    with open_grpc_channel(
        settings.api_address,
        ssl_creds_from_settings(settings),
    ) as channel:
        stub = voice_cloning_pb2_grpc.VoiceCloningStub(channel)

        response: voice_cloning_pb2.TaskId
        call: grpc.Call
        response, call = stub.CloneVoice.with_call(
            request,
            metadata=metadata,
            timeout=settings.timeout,
        )

        click.echo("Response metadata:")
        print_metadata(call.initial_metadata())

        click.echo(f"\nTask ID: {response.val}")
