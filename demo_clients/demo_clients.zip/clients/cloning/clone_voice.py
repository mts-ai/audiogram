import click
import grpc

from clients.common_utils.arguments import common_options_in_settings
from clients.common_utils.audio import AudioFile
from clients.common_utils.auth import get_auth_metadata
from clients.common_utils.config import SettingsProtocol
from clients.common_utils.errors import errors_handler
from clients.common_utils.grpc import open_grpc_channel, ssl_creds_from_settings
from clients.genproto import voice_cloning_pb2, voice_cloning_pb2_grpc


@click.command(
    no_args_is_help=True,
    help="Clone voice",
)
@errors_handler
@common_options_in_settings
@click.option(
    "--audio-file",
    type=click.Path(file_okay=True, dir_okay=False, readable=True),
    help="audio file path (required)",
    metavar="<file path>",
    required=True,
)
def clone_voice(
    settings: SettingsProtocol,
    audio_file: str,
) -> None:
    auth_metadata = get_auth_metadata(
        settings.sso_url,
        settings.realm,
        settings.client_id,
        settings.client_secret,
        settings.iam_account,
        settings.iam_workspace,
        settings.verify_sso,
    )

    audio = AudioFile(audio_file)

    click.echo(f"Request parameters:\nAudio file: {audio_file}\n")

    if audio.sample_rate != 16000:
        click.echo(f"Warning: Sample rate is {audio.sample_rate}Hz, expected 16000")

    request = voice_cloning_pb2.CloneVoiceRequest(signal=audio.blob)

    click.echo(f"Connecting to gRPC server - {settings.api_address}\n")
    with open_grpc_channel(
        settings.api_address,
        ssl_creds_from_settings(settings),
    ) as channel:
        stub = voice_cloning_pb2_grpc.VoiceCloningStub(channel)

        response: voice_cloning_pb2.TaskId
        call: grpc.Call
        response, call = stub.CloneVoice.with_call(
            request,
            metadata=auth_metadata,
            timeout=settings.timeout,
        )

        click.echo("Response metadata:")
        print(call.initial_metadata())

        click.echo(f"\nTask ID: {response.val}")
